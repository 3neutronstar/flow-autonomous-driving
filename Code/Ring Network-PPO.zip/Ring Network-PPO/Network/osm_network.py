from flow.networks import Network


class OsmNetwork(Network):
    pass
